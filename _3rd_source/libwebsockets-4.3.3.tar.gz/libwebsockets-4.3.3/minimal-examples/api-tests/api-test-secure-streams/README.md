# lws api test Secure Streams

Performs some tests against httpbin.org server
to check Secure Streams client performance

## build

```
 $ cmake . && make
```

## usage

Commandline option|Meaning
---|---
-d <loglevel>|Debug verbosity in decimal, eg, -d15

```
 $ ./lws-api-test-secure-streams
```

