|name|demonstrates|
---|---
minimal-http-client-certinfo|Shows how to gain detailed information on the peer certificate
minimal-http-client-custom-headers|Shows how to send and receive custom headers (h1 only)
minimal-http-client-hugeurl|Sends a > 2.5KB URL to warmcat.com
minimal-http-client-multi|Connects to and reads https://warmcat.com, 8 times concurrently
minimal-http-client-post|POSTs a form containing an uploaded file and a form variable, and captures the response
minimal-http-client|Connects to and reads https://warmcat.com
